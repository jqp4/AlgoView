changelog
===

**0.3.0**

- `Text2D` was renamed to `MeshText2D`
